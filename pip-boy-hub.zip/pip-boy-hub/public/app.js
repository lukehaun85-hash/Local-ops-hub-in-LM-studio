const $ = (id) => document.getElementById(id);
const nodeButtons = [...document.querySelectorAll('.node-btn')];
const panels = [...document.querySelectorAll('.node-panel')];

function setBusy(button, busy) { button.disabled = busy; button.dataset.original = button.dataset.original || button.textContent; button.textContent = busy ? 'PROCESSING...' : button.dataset.original; }

async function api(url, options = {}) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function pretty(value) { return typeof value === 'string' ? value : JSON.stringify(value, null, 2); }

nodeButtons.forEach((button) => button.addEventListener('click', () => {
  const id = button.dataset.node;
  nodeButtons.forEach((b) => b.classList.toggle('active', b === button));
  panels.forEach((panel) => panel.classList.toggle('hidden', panel.id !== id));
}));

$('janitorRun').addEventListener('click', async () => {
  const button = $('janitorRun');
  setBusy(button, true);
  $('janitorOutput').textContent = 'SCANNING...';
  try {
    const data = await api('/api/nodes/file-janitor/run', {
      method: 'POST',
      body: JSON.stringify({ root: $('janitorRoot').value || undefined, maxAgeDays: Number($('janitorAge').value), apply: $('janitorApply').checked }),
    });
    $('janitorOutput').textContent = pretty(data.result);
  } catch (error) {
    $('janitorOutput').textContent = `ERROR: ${error.message}`;
  } finally { setBusy(button, false); }
});

$('researchRun').addEventListener('click', async () => {
  const button = $('researchRun');
  const urls = $('researchUrls').value.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  setBusy(button, true);
  $('researchOutput').textContent = 'FETCHING SOURCES + CONSULTING LOCAL MODEL...';
  try {
    const data = await api('/api/nodes/research-digest/run', {
      method: 'POST',
      body: JSON.stringify({ urls, focus: $('researchFocus').value.trim() }),
    });
    $('researchOutput').textContent = `${data.result.digest}\n\nSOURCES\n${data.result.sources.map((s, i) => `[${i + 1}] ${s}`).join('\n')}`;
    if (data.result.model) $('modelReadout').textContent = `MODEL: ${data.result.model}`;
  } catch (error) {
    $('researchOutput').textContent = `ERROR: ${error.message}`;
  } finally { setBusy(button, false); }
});

async function refreshHealth() {
  try {
    const data = await api('/api/health');
    $('statusDot').style.color = 'var(--phosphor)';
    $('statusText').textContent = 'LM ONLINE';
    const model = data.models?.[0];
    if (model) $('modelReadout').textContent = `MODEL: ${model}`;
  } catch (error) {
    $('statusDot').style.color = 'var(--red)';
    $('statusText').textContent = 'LM OFFLINE';
  }
}

function tick() { $('clock').textContent = new Date().toLocaleTimeString(); }
refreshHealth();
setInterval(refreshHealth, 5000);
tick(); setInterval(tick, 1000);
