import OpenAI from 'openai';
import { config } from './config.js';

export const lm = new OpenAI({
  baseURL: config.lmStudioBaseUrl,
  apiKey: config.lmStudioApiKey,
});

export async function getModels() {
  const response = await fetch(`${config.lmStudioBaseUrl}/models`, {
    headers: { Authorization: `Bearer ${config.lmStudioApiKey}` },
  });
  if (!response.ok) throw new Error(`LM Studio /models returned ${response.status}`);
  return response.json();
}

export async function resolveModel(requestedModel = '') {
  if (requestedModel) return requestedModel;
  if (config.lmStudioModel) return config.lmStudioModel;
  const data = await getModels();
  const first = data?.data?.[0]?.id;
  if (!first) throw new Error('No LM Studio model is currently available. Load a model and start the server.');
  return first;
}

export async function chat(messages, options = {}) {
  const model = await resolveModel(options.model);
  const completion = await lm.chat.completions.create({
    model,
    messages,
    temperature: options.temperature ?? 0.2,
    max_tokens: options.maxTokens ?? 1200,
  });

  return {
    model,
    content: completion.choices?.[0]?.message?.content || '',
    usage: completion.usage || null,
    raw: completion,
  };
}
