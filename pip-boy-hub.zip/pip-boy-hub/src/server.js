import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { listNodes, registerNode, runNode } from './registry.js';
import { fileJanitorNode } from './nodes/fileJanitor.js';
import { researchDigestNode } from './nodes/researchDigest.js';
import { getModels } from './lmstudio.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

registerNode(fileJanitorNode);
registerNode(researchDigestNode);

app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/api/health', async (_req, res) => {
  try {
    const models = await getModels();
    res.json({ ok: true, lmStudio: true, models: models.data?.map((m) => m.id) || [] });
  } catch (error) {
    res.status(503).json({ ok: false, lmStudio: false, error: error.message });
  }
});

app.get('/api/nodes', (_req, res) => res.json({ nodes: listNodes() }));

app.post('/api/nodes/:id/run', async (req, res) => {
  try {
    const result = await runNode(req.params.id, req.body || {}, { config });
    res.json({ ok: true, node: req.params.id, result });
  } catch (error) {
    console.error(error);
    res.status(400).json({ ok: false, node: req.params.id, error: error.message });
  }
});

app.use((_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.listen(config.port, () => {
  console.log(`PIP-BOY HUB online at http://localhost:${config.port}`);
  console.log(`LM Studio target: ${config.lmStudioBaseUrl}`);
});
