import dotenv from 'dotenv';

dotenv.config();

export const config = {
  port: Number(process.env.PORT || 3000),
  lmStudioBaseUrl: process.env.LM_STUDIO_BASE_URL || 'http://127.0.0.1:1234/v1',
  lmStudioApiKey: process.env.LM_STUDIO_API_KEY || 'lm-studio',
  lmStudioModel: process.env.LM_STUDIO_MODEL || '',
  janitorRoot: process.env.JANITOR_ROOT || process.cwd(),
};
