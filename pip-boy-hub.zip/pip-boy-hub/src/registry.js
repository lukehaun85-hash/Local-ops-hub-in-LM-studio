const nodes = new Map();

export function registerNode(node) {
  if (!node?.id || !node?.run) throw new Error('Node must define id and run().');
  if (nodes.has(node.id)) throw new Error(`Duplicate node id: ${node.id}`);
  nodes.set(node.id, Object.freeze(node));
  return node;
}

export function getNode(id) {
  const node = nodes.get(id);
  if (!node) throw new Error(`Unknown node: ${id}`);
  return node;
}

export function listNodes() {
  return [...nodes.values()].map(({ id, name, description, inputSchema }) => ({
    id, name, description, inputSchema,
  }));
}

export async function runNode(id, input = {}, context = {}) {
  return getNode(id).run(input, context);
}
