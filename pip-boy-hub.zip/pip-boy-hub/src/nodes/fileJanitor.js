import path from 'node:path';
import { readdir, stat, unlink } from 'node:fs/promises';

const DEFAULT_EXTENSIONS = new Set(['.tmp', '.temp', '.bak', '.old', '.dmp', '.log']);

function isCandidate(name, info, now, maxAgeDays) {
  const ext = path.extname(name).toLowerCase();
  if (info.isFile() && DEFAULT_EXTENSIONS.has(ext)) return true;
  if (info.isFile() && name.startsWith('~$')) return true;
  const ageDays = (now - info.mtimeMs) / 86400000;
  return info.isFile() && ageDays > maxAgeDays && ext === '.log';
}

async function scan(root, maxAgeDays = 30) {
  const entries = await readdir(root, { withFileTypes: true });
  const now = Date.now();
  const candidates = [];

  for (const entry of entries) {
    if (entry.name === 'node_modules' || entry.name.startsWith('.')) continue;
    const fullPath = path.join(root, entry.name);
    if (!entry.isFile()) continue;
    const info = await stat(fullPath);
    if (isCandidate(entry.name, info, now, maxAgeDays)) {
      candidates.push({
        name: entry.name,
        path: fullPath,
        size: info.size,
        modifiedAt: new Date(info.mtimeMs).toISOString(),
      });
    }
  }
  return candidates;
}

export const fileJanitorNode = {
  id: 'file-janitor',
  name: 'File Janitor',
  description: 'Scans a configured folder for common temporary, backup, dump, and log files. Defaults to dry-run.',
  inputSchema: {
    root: { type: 'string', required: false },
    maxAgeDays: { type: 'number', default: 30 },
    apply: { type: 'boolean', default: false },
  },
  async run(input, context) {
    const root = path.resolve(input.root || context.config.janitorRoot);
    const maxAgeDays = Number(input.maxAgeDays ?? 30);
    const apply = Boolean(input.apply);

    const candidates = await scan(root, maxAgeDays);
    let deleted = 0;
    const errors = [];

    if (apply) {
      for (const item of candidates) {
        try {
          await unlink(item.path);
          deleted += 1;
        } catch (error) {
          errors.push({ path: item.path, message: error.message });
        }
      }
    }

    return {
      root,
      mode: apply ? 'APPLY' : 'PREVIEW',
      found: candidates.length,
      deleted,
      candidates: apply ? candidates.filter((x) => !errors.some((e) => e.path === x.path)) : candidates,
      errors,
      note: apply ? 'Matching files were deleted.' : 'Preview only. Set apply=true to delete matches.',
    };
  },
};
