import { chat } from '../lmstudio.js';

function stripHtml(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

async function fetchSource(url) {
  const response = await fetch(url, {
    headers: { 'User-Agent': 'PipBoyHub/0.1 (+local research digest)' },
  });
  if (!response.ok) throw new Error(`${url} returned ${response.status}`);
  const type = response.headers.get('content-type') || '';
  const text = await response.text();
  return { url, contentType: type, text: type.includes('html') ? stripHtml(text) : text };
}

export const researchDigestNode = {
  id: 'research-digest',
  name: 'Research Digest',
  description: 'Fetches supplied URLs and asks the local LM Studio model to produce a concise, cited digest.',
  inputSchema: {
    urls: { type: 'string[]', required: true },
    focus: { type: 'string', required: false },
  },
  async run(input) {
    const urls = Array.isArray(input.urls) ? input.urls.filter(Boolean).slice(0, 8) : [];
    if (!urls.length) throw new Error('Provide at least one URL.');

    const sources = [];
    const fetchErrors = [];
    for (const url of urls) {
      try {
        sources.push(await fetchSource(url));
      } catch (error) {
        fetchErrors.push({ url, message: error.message });
      }
    }
    if (!sources.length) throw new Error('None of the supplied URLs could be fetched.');

    const prompt = [
      'Create a research digest from the supplied sources.',
      'Rules:',
      '- Use only claims supported by the source text.',
      '- Separate established facts from uncertainty.',
      '- Summarize each source in 2-4 bullets.',
      '- Finish with 3 cross-source takeaways.',
      '- Cite sources inline using [1], [2], etc. corresponding to the source list.',
      input.focus ? `- Prioritize this focus: ${input.focus}` : '',
      '',
      ...sources.map((source, index) => `SOURCE [${index + 1}] ${source.url}\n${source.text.slice(0, 16000)}`),
    ].filter(Boolean).join('\n\n');

    const result = await chat([
      { role: 'system', content: 'You are a careful research analyst. Be concise and evidence-bound.' },
      { role: 'user', content: prompt },
    ], { temperature: 0.1, maxTokens: 1800 });

    return {
      model: result.model,
      digest: result.content,
      sources: sources.map((s) => s.url),
      fetchErrors,
      usage: result.usage,
    };
  },
};
