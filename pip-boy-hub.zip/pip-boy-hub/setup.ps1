$ErrorActionPreference = 'Stop'
Write-Host '== PIP-BOY Hub setup ==' -ForegroundColor Green
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js is not installed. Install Node.js 20+ and re-run.' }
Write-Host "Node: $(node --version)"
if (-not (Test-Path .env)) {
  Copy-Item .env.example .env
  Write-Host 'Created .env from .env.example. Edit JANITOR_ROOT and optionally LM_STUDIO_MODEL.' -ForegroundColor Yellow
}
npm install
Write-Host 'Setup complete. Start with: npm run dev' -ForegroundColor Green
